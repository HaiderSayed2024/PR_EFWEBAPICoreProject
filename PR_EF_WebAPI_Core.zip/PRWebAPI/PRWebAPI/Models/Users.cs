﻿using System.Text.Json.Serialization;

namespace PRWebAPI.Models
{
    public class Users
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        
        [JsonIgnore]
        public string Password { get; set; }
        public string UserType { get; set; }
        public int IsActive { get; set; } = 1;
        public DateTime CreatedOn { get; set; }



    }
}
