﻿using Microsoft.EntityFrameworkCore;

namespace PRWebAPI.Models
{
    public class PRContext : DbContext
    {
        public PRContext(DbContextOptions<PRContext> options) : base(options)
        {

        }

        public DbSet<ContactDetails> tblContactDetails { get;set; }
        public DbSet<InteractionDetails> tblInteractionDetails { get; set; }
        public DbSet<Users> tblUsers { get; set; }
    }
}
